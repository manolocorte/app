			VARIABLES NOT CONTROLLED

This document covers the usage of the ‘variables_not_controlled.json’ file.

- The file must be in JSON format where the keys are the name of the variables (fields in the Trial Design tables) in uppercase.

- The values of that keys must be lists with the allowable values for each variable.


= = License = =

This software is licensed under the GNU AGPL (https://www.gnu.org/licenses/why-affero-gpl.html).



= = Contact Us = =

Contact NIHPO (Jose.Lacal@NIHPO.com) for a commercial license, or if you're interested in licensing a customized version of this platform.

Version 24 May 2021